package com.cpg.onlineVegetableApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineVegetableAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineVegetableAppApplication.class, args);
		System.out.println("Started at 8086");
	}

}
